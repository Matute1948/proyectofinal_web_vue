
import axios from "axios";

const agregarReserva = async (reservaBody) => {
    try {
        const response = await axios.post(`http://localhost:8082/API/v1.0/Concesionario/reservas`,reservaBody).then(r=>r.data);
        console.log(response.data);
        return response.data;
    } catch (error) {
        console.error("Error al agregar reserva:", error);
        throw error; // O maneja el error como prefieras
    }
}


const registrarPago = async (pagoBody) => {
    try {
        const response = await axios.post(`http://localhost:8082/API/v1.0/Concesionario/reservaciones/pago`, {
            numeroTarjeta: pagoBody.numeroTarjeta,
            fechaCobro: pagoBody.fechaCobro,
            reservaId: pagoBody.reservaId
        });
        console.log(response.data);
        return response.data;
    } catch (error) {
        console.error("Error al registrar pago:", error);
        throw error; // O maneja el error como prefieras
    }
}

export const agregarReservaFachada= async(reservaBody) =>{
return await agregarReserva(reservaBody);
};

export const registrarPagoFachada= async(pagoBody) =>{
    return await registrarPago(pagoBody);
    };


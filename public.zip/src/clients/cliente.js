import axios from "axios";

// Función para agregar un cliente
const agregar = async (clienteBody) => {
    try {
        const response = await axios.post(`http://localhost:8082/API/v1.0/Concesionario/clientes`, clienteBody);
        const data = response.data;
        console.log(data);
        return data;
    } catch (error) {
        console.error("Error al agregar cliente:", error);
        throw error;
    }
};

// Función para actualizar un cliente
const actualizar = async (cedula, clienteBody) => {
    try {
        const response = await axios.put(`http://localhost:8082/API/v1.0/Concesionario/clientes/${cedula}`, clienteBody);
        const data = response.data;
        console.log(data);
        return data;
    } catch (error) {
        console.error("Error al actualizar cliente:", error);
        throw error;
    }
};

// Función para obtener detalle de una reserva
const obtenerDetalleReserva = async (numReserva) => {
    try {
        const response = await axios.get(`http://localhost:8082/API/v1.0/Concesionario/reservaciones/${numReserva}`);
        const data = response.data;
        console.log(data);
        return data;
    } catch (error) {
        console.error("Error al obtener detalle de reserva:", error);
        throw error;
    }
};

// Función para retirar un vehículo
const retirarVehiculo = async (numReserva) => {
    try {
        const response = await axios.post(`http://localhost:8082/API/v1.0/Concesionario/reservaciones/${numReserva}`);
        const data = response.data;
        console.log(data);
        return data;
    } catch (error) {
        console.error("Error al retirar vehículo:", error);
        throw error;
    }
};

// Funciones de fachada

export const agregarFachada = async (clienteBody) => {
    return await agregar(clienteBody);
};

export const actualizarFachada = async (clienteBody, cedula) => {
    return await actualizar(cedula, clienteBody);
};

export const obtenerDetalleReservaFachada = async (numReserva) => {
    return await obtenerDetalleReserva(numReserva);
};

export const retirarVehiculoFachada = async (numReserva) => {
    return await retirarVehiculo(numReserva);
};

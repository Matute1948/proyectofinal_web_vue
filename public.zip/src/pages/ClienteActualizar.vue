<template>
  <h1>Actualizar Cliente</h1>
  <ClienteFormulario/>
</template>

<script>
import ClienteFormulario from '@/components/ClienteFormulario.vue';
export default {
    components:{
        ClienteFormulario,
    }

}
</script>

<style>

</style>
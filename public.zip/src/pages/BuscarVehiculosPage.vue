<template>
<h1>Buscar Vehiculos</h1>
<BuscarVehiculosVue/>
  </template>

<script>
import BuscarVehiculosVue from '@/components/BuscarVehiculos.vue'
export default {
    components:{
        BuscarVehiculosVue
    }

}
</script>

<style>

</style>
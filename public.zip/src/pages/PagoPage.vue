<template>
  <PagoVue/>
</template>

<script>
import PagoVue from '@/components/Pago.vue'

export default {
components:{
    PagoVue
}
}
</script>

<style>

</style>
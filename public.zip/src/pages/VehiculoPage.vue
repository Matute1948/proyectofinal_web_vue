<template>
  <VehiculoVue/>
</template>

<script>
import VehiculoVue from '@/components/Vehiculo.vue'


export default {

    components:{
        VehiculoVue
    }

}
</script>

<style>

</style>
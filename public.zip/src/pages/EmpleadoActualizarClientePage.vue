<template>

    <div>
        <ClienteFormulario />
    </div>
</template>

<script >

import ClienteFormulario from '../components/ClienteFormulario.vue';
import Boton from '../components/Boton.vue';

export default {
    components: {
        ClienteFormulario,
        Boton
    }
}

</script>

<style scoped>

</style>
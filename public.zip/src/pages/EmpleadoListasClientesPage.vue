<template>
    <div>
        <ListasCliente />
    </div>
</template>

<script>
import ListasCliente from '../components/ListasCliente.vue';

export default {
    components: {
        ListasCliente
    }
}

</script>

<style scoped></style>
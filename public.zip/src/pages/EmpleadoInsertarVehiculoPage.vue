<template>
    <div>
      <h1>Insertar Vehículo</h1>
      <VehiculoFormularioInsertar />
    </div>
  </template>
  
  <script>
  import VehiculoFormularioInsertar from '@/components/VehiculoFormularioInsertar.vue';
  
  export default {
    components: {
      VehiculoFormularioInsertar
    }
  };
  </script>
  
  <style scoped>
  /* Estilos para la página */
  </style>
  
<template>
    <h1>Hola Bienvenidos a BUDGET</h1>
  </template>
  
  <script>
  export default {
  
  }
  </script>
  
  <style>
  
  </style>
<template>
  <ReservaVue/>
</template>

<script>
import ReservaVue from '@/components/Reserva.vue'
export default {
components:{
    ReservaVue
}
}
</script>

<style>

</style>
<template>
    <h1>Datos del cliente {{ apellido }} {{nombre}}</h1>
    <div class="informacion-container">
        <p>Apellido: {{ apellido }}</p>
        <p>Nombre: {{ nombre }}</p>
        <p>Cédula: 1234567890</p>
        <p>Fecha de nacimiento: 01/01/2000</p>
        <p>Género: M</p>
    </div>

    <Boton textoBoton="Volver" />
</template>

<script>

import Boton from '../components/Boton.vue';
import ClienteFormulario from '../components/ClienteFormulario.vue';

export default {
    components: {
        Boton,
        ClienteFormulario
    },
    data() {
        return {
            apellido: 'Pérez',
            nombre: 'Juan'
        }
    }
}

</script>

<style scoped></style>
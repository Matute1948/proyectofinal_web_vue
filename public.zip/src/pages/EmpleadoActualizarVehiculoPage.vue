<template>
    <div>
      <h1>Actualizar Vehículo</h1>
      <VehiculoFormularioActualizar />
    </div>
  </template>
  
  <script>
  import VehiculoFormularioActualizar from '@/components/VehiculoFormularioActualizar.vue';
  
  export default {
    components: {
      VehiculoFormularioActualizar
    }
  };
  </script>
  
  <style scoped>
  /* Estilos para la página */
  </style>
  
<template>
  <h1>Registro Clientes</h1>
  <ClienteFormulario/>
</template>

<script>
import ClienteFormulario from '@/components/ClienteFormulario.vue';
export default {
    components:{
        ClienteFormulario,

    }

}
</script>

<style>

</style>
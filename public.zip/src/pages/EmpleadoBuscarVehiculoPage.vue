<template>
    <div>
      <h1>Buscar Vehículos</h1>
      <VehiculoFormularioBuscar />
    </div>
  </template>
  
  <script>
  import VehiculoFormularioBuscar from '@/components/VehiculosFormularioBuscar.vue';
  
  export default {
    components: {
      VehiculoFormularioBuscar
    }
  };
  </script>
  
  <style scoped>
  /* Estilos para la página */
  </style>
  
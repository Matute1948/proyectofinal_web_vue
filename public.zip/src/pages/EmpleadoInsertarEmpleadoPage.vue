<template>
    <div>
        <h1>Insertar Cliente</h1>
        <p>Ingrese los datos del cliente</p>
    </div>
    <div class="formulario-container">
        <ClienteFormulario />
        <Boton textoBoton="Insertar" />
    </div>
</template>

<script>

import ClienteFormulario from '../components/ClienteFormulario.vue';
import Boton from '../components/Boton.vue';

export default {
    data(){
        return{

        }
    },
    components: {
        ClienteFormulario,
        Boton
    }
}
</script>

<style scoped></style>
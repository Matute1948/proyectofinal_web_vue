<template>
    <h1>Page no Found</h1>
    <h2>Asegurese de que la URL es correcta</h2>
  </template>
  
  <script>
  export default {
  
  }
  </script>
  
  <style>
  
  </style>
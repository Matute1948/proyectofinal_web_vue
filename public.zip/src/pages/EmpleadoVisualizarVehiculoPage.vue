<template>
    <div>
      <VehiculoVisualizar />
    </div>
  </template>
  
  <script>
  import VehiculoVisualizar from '@/components/VehiculoVisualizar.vue';
  
  export default {
    components: {
      VehiculoVisualizar
    }
  };
  </script>
  
  <style scoped>
  /* Estilos para la página */
  </style>
  
<template>
    <div >
        <h1>Bienvenido a la aplicación de clientes</h1>
        <p>En esta aplicación podrás registrar, buscar, actualizar y borrar clientes</p>
    </div>
</template>

<script >

</script>

<style scoped>

</style>
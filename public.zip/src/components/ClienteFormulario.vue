<template>
    <div class="formulario-container">
        <p><input type="text" name="" id="" placeholder="Apellido"></p>
        <p><input type="text" name="" id="" placeholder="Nombre"></p>
        <p><input type="text" name="" id="" placeholder="Cedula"></p>
        <p><label for="">Fecha de nacimiento</label></p>
        <p><input type="date" v-model="fecha" name="" id=""></p>
        <p>{{fecha}}</p>
        <p>
            <select id="genero" v-model="genero">
                <option value="" disabled selected class="opaco">Genero</option>
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
                <option value="O">Otro</option>
            </select>
        </p>

    </div>
</template>

<script>
export default {
    data() {
        return {
            genero: '',
            fecha: ''
        };
    }
}
</script>

<style scoped>
input {
    margin: 5px 0px;
    padding: 10px 20px;
    border-radius: 5px;
    border: solid 1px black;
}
select {
    width: 150px;
    height: 40px;
    border-radius: 5px;
}

</style>
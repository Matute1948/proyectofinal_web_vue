<template>
  <div class="container">
    <div class="datos">
      <p type="Cedula:"><input v-model="cedula" type="text"></p>
      <p type="Placa:"><input v-model="placa" type="text"></p>
      <p type="Fecha de Inicio:"><input v-model="fechaDeInicio" type="date"></p>
      <p type="Fecha de Finalizacion:"><input v-model="fechaDeFin" type="date"></p>
    </div>
    <div class="boton">
      <button @click="guardar">Pagar</button>
    </div>
  </div>
</template>

<script>
import { agregarReservaFachada } from '@/clients/clienteReserva.js'

export default {
  data() {
    return {
      placa: '',
      cedula: '',
      fechaDeInicio: null,
      fechaDeFin: null,
    }
  },
  methods: {
    async guardar() {
      const bodyReserva = {
        placaVehiculo: this.placa,
        cedulaCliente: this.cedula,
        fechaDeInicio: this.fechaDeInicio,
        fechaDeFin: this.fechaDeFin
      }

      try {
        const response = await agregarReservaFachada(bodyReserva);
        console.log('Reserva creada con éxito:', response);
        // Aquí puedes redirigir a la página de pago, si es necesario
        this.$router.push('/pago');
      } catch (error) {
        console.error('Error al agregar reserva:', error);
        // Aquí puedes mostrar un mensaje al usuario, si lo deseas
      }
    }
  }
}
</script>

<style scoped>
p::before {
  content: attr(type);
}
</style>

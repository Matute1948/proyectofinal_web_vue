<template>
  <div class="form-container">
    <h1>Insertar Vehículo</h1>
    <form @submit.prevent="insertarVehiculo">
      <div class="form-group">
        <label>Placa:</label>
        <input type="text" v-model="vehiculo.placa" required>
      </div>
      <div class="form-group">
        <label>Modelo:</label>
        <input type="text" v-model="vehiculo.modelo" required>
      </div>
      <div class="form-group">
        <label>Marca:</label>
        <input type="text" v-model="vehiculo.marca" required>
      </div>
      <div class="form-group">
        <label>Año de fabricación:</label>
        <input type="text" v-model="vehiculo.anio" required>
      </div>
      <div class="form-group">
        <label>País de fabricación:</label>
        <input type="text" v-model="vehiculo.paisOrigen" required>
      </div>
      <div class="form-group">
        <label>Cilindraje:</label>
        <input type="number" v-model="vehiculo.cilindraje" required>
      </div>
      <div class="form-group">
        <label>Avalúo:</label>
        <input type="number" v-model="vehiculo.avaluo" required>
      </div>
      <div class="form-group">
        <label>Valor por día:</label>
        <input type="number" v-model="vehiculo.valorPorDia" required>
      </div>
      <button type="submit">Insertar</button>
    </form>
  </div>
</template>

<script>
import { agregarFachada } from '@/clients/vehiculos';

export default {
  data() {
    return {
      vehiculo: {
        placa: '',
        modelo: '',
        marca: '',
        anio: '',
        paisOrigen: '',
        cilindraje: 0,
        avaluo: 0,
        valorPorDia: 0
      }
    };
  },
  methods: {
    async insertarVehiculo() {
      try {
        const response = await agregarFachada(this.vehiculo);
        console.log('Vehículo insertado:', response);
        // Aquí puedes agregar lógica adicional, como redirigir a otra página o mostrar un mensaje de éxito
      } catch (error) {
        console.error('Error al insertar el vehículo:', error);
        // Aquí puedes agregar lógica adicional, como mostrar un mensaje de error
      }
    }
  }
};
</script>

<style scoped>
.form-container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f7f7f7;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
  text-align: center;
  color: #333;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}

input[type="text"],
input[type="number"] {
  width: calc(100% - 20px);
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 16px;
}

button:hover {
  background-color: #0056b3;
}
</style>

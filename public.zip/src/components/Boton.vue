<template>
    <div>
        <button>{{textoBoton}}</button>
        <button @click="cambiarPagina">{{ textoBoton }}</button>
    </div>
</template>

<script>

export default {
    props: {
        textoBoton: {
            type: String,
            required: true
        },
        dirigirA: {
            type: String,
            required: false
        }
    },
    methods: {
        cambiarPagina() {
            if (this.to) {
                this.$router.push(this.dirigirA);
            } else {
                this.$emit('click');
            }
        }
    }
}

</script>

<style scoped>
button {
    margin: 5px 0px;
    height: 40px;
    width: 100px;
    border-radius: 5px;
    border: solid 1px black;
    background-color: black;
    color: white;
}

button:hover {
    background: rgb(82, 82, 82);
    color: rgb(255, 255, 255);
    cursor: pointer;
}
</style>
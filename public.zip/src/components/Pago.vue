<template>
  <div class="container">
    <div class="datos">
        <p type="Cedula:"><input  type="text"></p>
        <p type="Placa:"><input  type="text"></p>
        <p type="Fecha de Inicio:"><input type="date"></p>

    </div>
    <div class="boton">
<button>Guardar</button>
    </div>

    </div>
</template>

<script>
export default {

}
</script>

<style>
p::before{
    content: attr(type);
}
</style>
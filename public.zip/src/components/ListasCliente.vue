<template>
    <div>
        <p>
            <input type="text" placeholder="Buscar por apellido">
            <Boton  textoBoton="Buscar" />
        </p>

        <div class="tabla-container">
            <table>
                <thead>
                    <tr>
                        <th>Apellido</th>
                        <th>Nombre</th>
                        <th>Cédula</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>
                    <tr v-for="cliente in clientes" :key="cliente.id">
                        <td>{{ cliente.lastName }}</td>
                        <td>{{ cliente.firstName }}</td>
                        <td>{{ cliente.cedula }}</td>
                        <td class="espacio-botones-container">
                            <div class="botones-container">
                                <Boton textoBoton="Ver" :cambiarPagina="`/verClienteE`" />
                                <Boton textoBoton="Actualizar" />
                                <Boton textoBoton="Eliminar" />
                            </div>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>

import Boton from './Boton.vue';

export default {
    components: {
        Boton
    },

    data() {
        return {
            clientes: [
                {
                    id: 1,
                    lastName: 'Pérez',
                    firstName: 'Juan',
                    cedula: '1234567890'
                },
                {
                    id: 2,
                    lastName: 'Gómez',
                    firstName: 'María',
                    cedula: '0987654321'
                }
            ]
        };
    }
}

</script>

<style scoped>
input {
    margin: 5px 0px;
    padding: 10px 20px;
    border-radius: 5px;
    border: solid 1px black;
}

.tabla-container {
    display: flex;
    justify-content: center;
    align-items: center;
}

table {
    border-collapse: collapse;
    width: 100%;
}

th,
td {
    text-align: center;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #f2f2f2
}

th {
    background-color: #464646;
    color: white;
}

.botones-container {
    width: 100%;
    display: flex;
    justify-content: space-around;
}
.espacio-botones-container {
    width: 400px;
}
</style>
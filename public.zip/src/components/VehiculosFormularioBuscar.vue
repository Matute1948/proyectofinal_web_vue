<template>
  <div class="buscar-container">
    <form @submit.prevent="buscarVehiculos">
      <div>
        <label>Marca:</label>
        <input type="text" v-model="marca" required>
      </div>
      <button type="submit">Buscar</button>
    </form>
 
    <div v-if="vehiculos.length">
      <h2>Resultados:</h2>
      <table>
        <thead>
          <tr>
            <th>Placa</th>
            <th>Modelo</th>
            <th>Marca</th>
            <th>Año de Fabricación</th>
            <th>Estado</th>
            <th>Valor por Día</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="vehiculo in vehiculos" :key="vehiculo.placa">
            <td>{{ vehiculo.placa }}</td>
            <td>{{ vehiculo.modelo }}</td>
            <td>{{ vehiculo.marca }}</td>
            <td>{{ vehiculo.anio }}</td>
            <td>{{ vehiculo.estado }}</td>
            <td>{{ vehiculo.valorPorDia }}</td>
            <td>
              <button @click="eliminarVehiculo(vehiculo.placa)">Eliminar</button>
              <button @click="irActualizarVehiculo(vehiculo.placa)">Actualizar</button>
              <button @click="irVisualizarVehiculo(vehiculo.placa)">Visualizar</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div v-if="mensajeError" class="mensaje-error">
      <p>{{ mensajeError }}</p>
      <button @click="cerrarMensajeError">Aceptar</button>
    </div>
  </div>
</template>

<script>
import { buscarPorMarcaFachada, eliminarFachada,buscarPorMarcaModeloFachada } from '../clients/vehiculos.js'; // Asegúrate de ajustar la ruta de importación

export default {
  data() {
    return {
      marca: '',
      vehiculos: [],
      mensajeError: ''
    };
  },
  methods: {
    async buscarVehiculos() {
      try {
        this.vehiculos = await buscarPorMarcaFachada(this.marca);
      } catch (error) {
        console.error(error);
        this.mensajeError = 'Error al buscar vehículos. Asegúrate de que la marca sea correcta.';
      }
    },
    async eliminarVehiculo(placa) {
      try {
        await eliminarFachada(placa);
        this.vehiculos = this.vehiculos.filter(vehiculo => vehiculo.placa !== placa);
      } catch (error) {
        console.error(error);
        this.mensajeError = `No se puede eliminar el vehículo con placa ${placa}.`;
      }
    },
    irActualizarVehiculo(placa) {
      this.$router.push({ path: `/vehiculo/actualizar/${placa}` });
    },
    irVisualizarVehiculo(placa) {
      this.$router.push({ path: `/vehiculo/visualizar/${placa}` });
    },
    cerrarMensajeError() {
      this.mensajeError = '';
    },
   
  }
};
</script>

<style scoped>
/* Estilos para el formulario */
form {
  margin-bottom: 20px;
}

/* Estilos para la tabla */
table {
  width: 100%;
  border-collapse: collapse;
}

th, td {
  padding: 10px;
  border: 1px solid #ddd;
  text-align: left;
}

th {
  background-color: #f4f4f4;
}

/* Estilos para los botones de la tabla */
button {
  margin: 5px;
  padding: 5px 10px;
  border: none;
  background-color: #007bff;
  color: white;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

/* Estilos para el mensaje de error */
.mensaje-error {
  margin-top: 20px;
  padding: 10px;
  border: 1px solid red;
  background-color: #f8d7da;
  color: #721c24;
}

.buscar-container {
  margin: 20px 40px;
}
</style>

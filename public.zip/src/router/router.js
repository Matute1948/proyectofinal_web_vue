import { createRouter, createWebHashHistory } from 'vue-router';

import MenuInicio from '@/pages/MenuInicio.vue'
import ClienteRegistro from '@/pages/ClienteRegistro.vue'
import ClienteActualizar from '@/pages/ClienteActualizar.vue'
import EmpleadoInsertarEmpleadoPage from '@/pages/EmpleadoInsertarEmpleadoPage.vue'
import BuscarVehiculosPage from '@/pages/BuscarVehiculosPage.vue'
import EmpleadoInsertarVehiculoPage from '@/pages/EmpleadoInsertarVehiculoPage.vue'
import EmpleadoBuscarVehiculoPage from '@/pages/EmpleadoBuscarVehiculoPage.vue'
import EmpleadoVisualizarVehiculoPage from '@/pages/EmpleadoVisualizarVehiculoPage.vue'
import NotFoundPage from '@/pages/NotFOundPage.vue'
import EmpleadoVerClientePage from '@/pages/EmpleadoVerClientePage.vue'
import EmpleadoListasClientesPage from '@/pages/EmpleadoListasClientesPage.vue'

import EmpleadoActualizarClientePage from '@/pages/EmpleadoActualizarClientePage.vue'
import ReporteReservas from '@/pages/ReporteReservas.vue'
import RetirarVehiculo from '@/pages/RetirarVehiculo.vue'
import EmpleadoActualizarVehiculoPage from '@/pages/EmpleadoActualizarVehiculoPage.vue'

import ReservaPage from '@/pages/ReservaPage.vue'
import PagoPage from '@/pages/PagoPage.vue'





const routes = [
  {
    path: '/',
    name: 'Bienvenida',
    component: MenuInicio, // O puedes usar BienvenidaPage si es lo que deseas
  },
  {
    path: '/ClienteRegistro',
    name: 'ClienteRegistro',
    component: ClienteRegistro,
  },
  {
    path: '/ClienteActualizar',
    name: 'ClienteActualizar',
    component: ClienteActualizar,
  },
  {
    path: '/registarE',
    component: EmpleadoInsertarEmpleadoPage
  },
  {
    path: '/buscarVehiculos',
    component: BuscarVehiculosPage
  },
  {
    path: '/vehiculo/insertar',
    component: EmpleadoInsertarVehiculoPage
  },
  {
    path: '/vehiculo/buscar',
    component: EmpleadoBuscarVehiculoPage
  },
  {
    path: '/vehiculo/visualizar/:placa',
    name: 'VisualizarVehiculo',
    component: EmpleadoVisualizarVehiculoPage,
    props: true
  },
  {
    path: '/vehiculo/actualizar/:placa',
    name: 'ActualizarVehiculo',
    component: EmpleadoActualizarVehiculoPage,
    props: true
  },
  {
    path: '/RetirarVehiculo',
    name: 'RetirarVehiculo',
    component: RetirarVehiculo,
  },
  {
    path: '/ReporteReservas',
    name: 'ReporteReservas',
    component: ReporteReservas,
  },
  {
    path: '/actualizarClienteE',
    component: EmpleadoActualizarClientePage
  },
  {
    path: '/buscarE',
    component: EmpleadoListasClientesPage
  },
  {
    path: '/verClienteE',
    component: EmpleadoVerClientePage
  },
  {
    path: '/:pathMatch(.*)*',
    component: NotFoundPage
  },
  {
    path: '/reservacion',
    component: ReservaPage
  },
  {
    path: '/pago',
    component: PagoPage
  }
];

const router = createRouter({
  history: createWebHashHistory(),
  routes
});

export default router;
